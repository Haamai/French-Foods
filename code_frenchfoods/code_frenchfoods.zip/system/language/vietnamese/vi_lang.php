<?php
    # Header
    $lang['email']   	=   "hahahuhu";
    $lang['taikhoan']		=   "Mfgdfgfd";
    $lang['passconf']		=   "Xác nhận Mật khẩu";
    $lang['matches']		=   "Trường '%s' không khớp với trường '%s'.";
    $lang['required']   	=   "Trường '%s' là bắt buộc.";
    $lang['invalid-email']  =   "Email này không hợp lệ.";