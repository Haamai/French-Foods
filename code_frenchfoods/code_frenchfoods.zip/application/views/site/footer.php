
<footer>
              <ul>
                  <li>
                      <div class="text">
                          <h4>FRENCHFOODS</h4>
                          <div>Cũng là những món ăn truyền thống của xứ “Kinh đô ánh sáng”: Beefsteak, pate gan ngỗng, thịt nguội Forma, sườn cừu nướng nhập khẩu,… nhưng tại nhà hàng Pháp ở Hà Nội này, thực khách sẽ cảm nhận được sự tỉ mỉ trong từng sáng tạo của người đầu bếp. Tiếp thu những tinh túy của ẩm thực Pháp kết hợp với sự đầu tư công phu của người đầu bếp đã mang lại sự mới lạ với các món ăn tại đây.</div><br>
                          <img src="<?php echo public_url()?>/site/image/logo.png" width='150px'>
                      </div>
                  </li>
                  <li>
                      <div class="text">
                          <h4>Địa chỉ</h4>
                          <div>Cơ sở 1: Tầng 2, Trung tâm đào tạo CNTT và Truyền Thông, Số 1 Hoàng Đạo Thúy, Quận Thanh Xuân, Hà Nội.<br><br>Cơ sở 2: Tầng 1, Nhà A2, Trường Đại học Sân Khấu - Điện Ảnh Hà Nội. Đường Hồ Tùng Mậu, Phường Mai Dịch, Quận Cầu Giấy, Hà Nội<br><br>Cơ sở 3: Tầng 7, Số 51, Đường Lê Đại Hành, Phường Lê Đại Hành, Quận Hai Bà Trưng, Hà Nội<br><br>Điện thoại: 024 3754 6732 Hotline: 0966 205 643<br>Email: info@itplus-academy.edu.vn</div>
                      </div>
                  </li>
                  <li>
                      <div class="text">
                          <h4>Liên hệ</h4>
                          <div>
                              <a href="<?php echo site_url('thucdon/datban') ?>">Đặt bàn</a><br>
                              <a href="<?php echo site_url('sukien/dktcsk') ?>">Đăng ký tổ chức sự kiện</a><br>
                              <a href="<?php echo site_url('sukien/tuyendung') ?>">Tuyển dụng</a><br>
                              <a href="<?php echo site_url('lienhe/ttcn') ?>">Tài khoản cá nhân</a>
                              <div style="margin-top: 20px">
                                  <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FHocVienITPlusAcademy%2F&tabs=events&width=279&height=150&small_header=true&adapt_container_width=false&hide_cover=false&show_facepile=false&appId" width="279" height="150" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
                              </div>
                          </div>
                  </li>
              </ul>
              <div class="bar">
                  <div class="bar-wrap">
                      <ul class="links">
                          <li><a href="<?php echo site_url('trangchu/index') ?>">Trang chủ</a></li>
                          <li><a href="<?php echo site_url('thucdon/monan') ?>">Thực đơn</a></li>
                          <li><a href="<?php echo site_url('sukien/khuyenmai') ?>">Sự kiện</a></li>
                          <li><a href="<?php echo site_url('bst/bst4mua') ?>">Bộ sưu tập</a></li>
                          <li><a href="<?php echo site_url('blog/index') ?>">Blog</a></li>
                          <li><a href="<?php echo site_url('lienhe/dclienhe') ?>">Liên hệ</a></li>
                    </ul>
                    <div class="social">
                        <a href="https://www.facebook.com/hoangvu012.vn" class="fb">
                            <img src="<?php echo public_url()?>/site/image/fb.png" class='icon' >
                            <span class="info">
                                <span class="follow">Become a Facebook</span>
                            </span>
                        </a>

                        <a href="https://www.instagram.com/_.beooo._/" class="tw">
                            <img src="<?php echo public_url()?>/site/image/ins.png" class='icon' >
                            <span class="info">
                                <span class="follow">Follow us Instagram</span>
                            </span>
                        </a>
                        <a href="https://twitter.com/itplusacademy" class="rss">
                            <img src="<?php echo public_url()?>/site/image/tw.png" class='icon' >
                            <span class="info">
                              <span class="follow">Follow us Twitter</span>
                          </span>
                      </a>
                  </div>
                  <div class="clear"></div>
                  <div class="copyright">&copy;  2019 All Rights Reserved</div>
              </div>
            </div>
      </footer>
  <script src="<?php echo public_url()?>/site/css/jquery-3.3.1.min.js"></script>
  <script src="<?php echo public_url()?>/site/css/bootstrap/js/bootstrap.min.js"></script>
