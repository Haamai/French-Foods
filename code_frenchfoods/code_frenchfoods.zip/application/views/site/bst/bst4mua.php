<!DOCTYPE html>
<html lang="en">
<body>
<?php $this->load->view('site/header')?>
<div>
  <div class="clear"></div>

<div class="container bst" style="text-align: justify;">
    <p>
      <h1><center>Ẩm thực bốn mùa ở nước Pháp</center></h1>
      <span>
      Đối với người Pháp ăn uống là một nghệ thuật, từ món ăn cách trình bay cho đến tư thế thưởng thức cũng đạt đến độ tinh tế và thanh lich. Ẩm thực Pháp khiến cả thế giới phải ngả mũ thán phục vì luôn toát lên thần thái sang trọng đẳng cấp. Ẩm thực Pháp vô cùng đa dạng, phong phú và thay đổi theo vùng, theo mùa. Bài viết này French Foods sẽ giới thiệu cho các bạn ẩm thực bốn mùa ở nước Pháp.
      </span><br>
      <!-- Carousel -->
<div id="myCarousel" class="carousel slide" data-ride="carousel" style="width: 80%;margin-top: 20px;margin-bottom: 20px;margin: auto">
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
    <li data-target="#myCarousel" data-slide-to="3"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="<?php echo public_url()?>/site/image/monan/vichyssoise.jpg" alt="" class='w-100' height='400px'>
    </div>
    <div class="carousel-item">
      <img src="<?php echo public_url()?>/site/image/monan/nicoise_salad.jpg" alt="" class='w-100' height='400px'>
    </div>
    <div class="carousel-item">
      <img src="<?php echo public_url()?>/site/image/monan/escargots.jpg" alt="" class='w-100' height='400px'>
    </div>
    <div class="carousel-item">
      <img src="<?php echo public_url()?>/site/image/monan/cheese_baked_oysters.jpg" alt="" class='w-100' height='400px'>
    </div>
  </div>
  <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
    <span class="sr-only">Next</span>
  </a>
</div>
      <span><img src="<?php echo public_url()?>/site/image/monan/vichyssoise.jpg" align="right" class="imgbst" style="width: 350px;margin-left: 10px;margin-top: 10px;height: 250px;">
      
      Mỗi đất nước trên thế giới lại có những sáng tạo món ăn thú vị để giúp thổi bay đi cái nóng oi ả của mùa hè. Có nơi ưa chuộng những món ăn ngọt ngào nhất, có nơi lại yêu thích những thực phẩm rau xanh hoa quả tươi ngon theo mùa, hương vị mát lạnh luôn nhận được nhiều sự yêu thích, thế nhưng ăn gì để đánh tan cái nóng lại đầy đủ dinh dưỡng luôn là vẫn đề nan giải đối với mỗi người. Do đó French Foods xin giới thiệu tới bạn một món ăn Pháp thanh mát, bổ dưỡng dành cho mùa hè này, nó có tên là Vichyssoise. Vichyssoise là món súp lạnh thanh tao được chế biến từ nguyên liệu là khoai tây, tỏi tây, hành tây, kem và thịt gà. Món ăn có màu vani tuyệt đẹp cùng sự thống nhất trong hương vị. Nó được phục vụ ở nhiệt độ lạnh để giữ tối đa cho hương vị nhẹ nhàng và tươi mới. Theo truyền thống được phục vụ lạnh nhưng nó có thể được ăn nóng. Mặc dù công thức nấu ăn của Pháp với các món súp tương tự đã tồn tại trong nhiều thế kỷ. Tuy nhiên, vị đầu bếp cuối cùng sáng chế ra phiên bản hoàn hảo nhất của món ăn này là Louis Diat, ông cũng là người đặt tên cho nó là “vichyssoise” tại khách sạn The Ritz-Carlton.
      </span><br>
      <span><img src="<?php echo public_url()?>/site/image/monan/nicoise_salad.jpg" align="left" class="imgbst1" style="width: 350px;margin-right: 10px;height: 250px;margin-top: 10px">
      Nói về nước Pháp, người ta thường nghĩ ngay đến đất nước của tình yêu. Mùa nào Pháp cũng mang vẻ đẹp riêng. Nhưng chỉ khi mùa thu đến, sự ngọt ngào, lãng mạn của quốc gia nơi trời Âu này mới hiện lên rõ rệt và đậm nét. Không rực rỡ như mùa xuân hay chói chang như mùa hè, mùa thu nước Pháp mang vẻ bình yên và quyến rũ du khách thập phương bằng quả mọng với lá vàng. Vì vậy French Foods xin giới thiệu tới các bạn một món ăn món ăn không thể bỏ qua vào mùa thu. Nicoise salad là một món xa lát gồm cà chua, cá ngừ, trứng luộc già, ô liu vùng Nice và cá cơm biển trộn với dầu giấm. Ngoài các thành phần kể trên, món xa lát này có thể có thêm ớt chuông, hành khô và hoa atisô sống. Trái ngược với những gì được phục vụ ở các quán ăn, theo một số nguồn thì ngoại trừ đậu xanh và khoai tây, món xa lát này không gồm rau củ nấu chín, cơm, đậu đũa. Tuy nhiên món ăn không có một công thức chính thức, do vậy mỗi đầu bếp có thể quyết định công thức riêng của mình. Món xa lát này theo truyền thống thường được khuyên dùng với vang hồng, vang trắng hoặc vang đỏ.
      </span><br>
      <span><img src="<?php echo public_url()?>/site/image/monan/escargots.jpg" align="right" class="imgbst" style="width: 350px;margin-left: 10px;height: 250px;margin-top: 10px">
      Mùa đông ở nước Pháp hội tụ đầy đủ các yếu tố vừa lạnh vừa ấm lại vừa có tuyết rải rác trên khắp đất nước, thật thích hợp khi cùng bạn bè thưởng thức Escargot. Thông thường, các món ăn làm từ ốc sên sẽ là những món khai vị trong bữa ăn của người Pháp. Escargot là cách người Pháp gọi ốc sên và là một cái tên vô cùng quen thuộc trong các thực đơn tại nhà hàng Pháp trên toàn thế giới. Trước khi nấu, ốc sên được cho ăn những loại thảo dược đặc biệt để tẩy sạch hệ tiêu hóa của chúng, rồi sơ chế bằng cách rửa, luộc và nấu. Các công đoạn trên có thể kéo dài tới vài ngày. Sự kỳ công đó lý giải vì sao món ốc sên rất đắt đỏ và chỉ dành cho giới sành ăn ở Pháp. Khi chế biến ốc sên được làm sạch, lấy ra khỏi vỏ để chế biến rồi đặt lại vào vỏ với bơ và sốt để phục vụ thực khách. Cách phổ biến nhất là kết hợp ốc sên với bơ và tỏi, gà hoặc rượu vang. Một số nguyên liệu gia tăng hương vị có thể thêm vào như cỏ xạ hương, mùi tây, hạt thông. Mỗi cách chế biến lại mang hương vị độc đáo riêng nhưng nổi bật hơn cả vẫn là hương vị đậm đà của ốc sên, khiến bất cứ ai cũng không thể quên khi đã một lần thưởng thức. Trên bàn ăn, ốc sên thường được bày 6 - 12 con một đĩa và luôn đi kèm mỗi người một bộ gắp, dĩa lấy ruột ốc cho khách dễ ăn.
      </span><br>
      <span><img src="<?php echo public_url()?>/site/image/monan/cheese_baked_oysters.jpg" align="left" class="imgbst1" style="width: 350px;margin-right: 10px;height: 250px;margin-top: 10px">
      Vào mùa xuân, từ tháng 3 đến tháng 5, thời tiết khá dễ chịu. Nhiệt độ vừa phải và có nắng đẹp dù mùa này thường xuyên có mưa. Chẳng có lí do gì để chúng ta từ chối một món ăn hấp dẫn lại thú vị nhưng giá cả lại phải chăng. Bên cạnh các món sò nướng mỡ hành cùng đậu phộng đã có mặt từ lâu đời, vài năm trở lại đây, các tín đồ ốc lại đâm nghiện thêm các món nướng phủ phô mai béo ngậy. Trong số đó, hàu nướng phô mai có vẻ được lòng mọi người hơn cả, bởi cái vị ngọt, chắc và mập thịt của hàu được hỗ trợ thêm bởi cái béo ngậy khó cưỡng của phô mai, thật khiến người ta khó có thể chối từ. Chẳng thế mà mỗi khi đi ăn, lúc nào nhìn quanh cũng thấy bàn nào cũng gọi vài con hàu nướng phô mai cả. Hàu đút lò với phô mai và tỏi là món ăn được nhiều người yêu thích vì hương vị thơm ngon lại giàu chất dinh dưỡng. Món hàu nướng phô mai nên thưởng thức khi còn nóng để có thể cảm nhận được vị ngon một cách trọn vẹn nhất. Thịt hàu đậm đà quyện với phô mai béo ngậy thơm lừng khiến bạn không thể dừng lại mà chỉ muốn được ăn thêm thật nhiều, thật nhiều hơn nữa.
      </span>
    </p>
  </div>

     <div class="clear"></div>
   </div>
    <?php $this->load->view('site/footer');?>
    </body>
    <script type="text/javascript"></script>
</body>
</html>

