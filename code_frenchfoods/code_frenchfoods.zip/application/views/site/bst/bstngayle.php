<!DOCTYPE html>
<html lang="en">
<body>
<?php $this->load->view('site/header')?>
<div>
  <div class="clear"></div>
  
<div class="container bst" style="text-align: justify;">
    <p>
      <h1><center>Chinh phục nàng ngày Lễ tình nhân.</center></h1>
      <span> 
      Đối với người Pháp ăn uống là một nghệ thuật, từ món ăn cách trình bay cho đến tư thế thưởng thức cũng đạt đến độ tinh tế và thanh lịch. Ẩm thực Pháp khiến cả thế giới phải ngả mũ thán phục vì luôn toát lên thần thái sang trọng đẳng cấp. Lấy cảm hứng từ sự kết hợp giữa việc nâng niu thể chất, trí tuệ lẫn tinh thần, nhà hàng French Foods với đội ngũ đầu bếp chuyên nghiệp đã sáng tạo thực đơn bữa tối 5 món cho ngày Lễ tình nhân. Những thực đơn này được phục vụ từ ngày 11 đến ngày 14/2 sắp tới. Con đường ngắn nhất dẫn đến cánh cửa trái tim là đi qua đường dạ dày. Vậy nên, lựa chọn thực đơn tinh tế sẽ giúp bạn và người ấy có một ngày Lễ tình nhân thật sự trọn vẹn.
      </span><br>
      <!-- Carousel -->


<div id="myCarousel" class="carousel slide" data-ride="carousel" style="width: 80%;margin-top: 20px;margin-bottom: 20px;margin: auto">
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
    <li data-target="#myCarousel" data-slide-to="3"></li>
    <li data-target="#myCarousel" data-slide-to="4"></li>

  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="<?php echo public_url()?>/site/image/monan/fresh_oysters.jpg" alt="" class='w-100' height='400px'>
    </div>
    <div class="carousel-item">
      <img src="<?php echo public_url()?>/site/image/monan/grilled_lamb_rack.jpg" alt="" class='w-100' height='400px'>
    </div>
    <div class="carousel-item">
      <img src="<?php echo public_url()?>/site/image/monan/beef_wellingtons.jpg" alt="" class='w-100' height='400px'>
    </div>
    <div class="carousel-item">
      <img src="<?php echo public_url()?>/site/image/monan/nicoise_salad.jpg" alt="" class='w-100' height='400px'>
    </div>
    <div class="carousel-item">
      <img src="<?php echo public_url()?>/site/image/monan/creme_brulee.jpg" alt="" class='w-100' height='400px'>
    </div>
  </div>
  <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
    <span class="sr-only">Next</span>
  </a>
</div>

      <span>
        <img src="<?php echo public_url()?>/site/image/monan/fresh_oysters.jpg" align="right" class="imgbst" style="width: 350px;margin-left: 10px;margin-top: 10px;height: 250px;">
        
        Bữa tối dành cho các cặp tình nhân tại nhà hàng bắt đầu với món khai vị. Nổi tiếng với tên gọi thức ăn cho tình yêu, vua hàu vịnh Coffin: thêm một sự lựa chọn sang chảnh cho ngày Lễ tình nhân nếu bạn là người "rủng rỉnh" ví tiền. Vua hàu vịnh Coffin là loài hàu lớn nhất thế giới với chiều dài 18cm và cân nặng gần 1kg, thường được ăn kèm với chanh thái lát, mang lại hương vị độc đáo và ngon miệng. Đây được coi là loài hàu lớn nhất thế giới nên giá bán của nó cũng thuộc hàng cao "nhất quả đất". Để thưởng thức món ăn này, thực khách phải bỏ ra 100 đô la cho mỗi con hàu. Tuy nhiên nhiều khách hàng cũng cho rằng hàu vịnh Coffin "xứng đáng" để thưởng thức bởi vị ngon đặc biệt, hương vị độc đáo. Các cặp đôi có thể tận hưởng bữa tối ấm áp trong khi ngắm nhìn bầu trời thơ mộng qua khung cửa sổ dưới ánh nến lung linh và cuốn theo giai điệu du dương của tiếng đàn piano. Thêm vào đó, hoa hồng và sô cô la dành tặng cho các cặp đôi sẽ hoàn thiên một ngày Lễ tình nhân trọn vẹn. French Foods cũng đưa ra nhiều món quà tặng Lễ tình nhân phong phú từ ngày 11 đến ngày 14/2 để khách lựa chọn dành tặng người thương yêu của mình.
      </span><br>
      <span>
        <img src="<?php echo public_url()?>/site/image/monan/grilled_lamb_rack.jpg" align="left" class="imgbst1" style="width: 350px;margin-right: 10px;height: 250px;margin-top: 10px">
        
        Món chính trong thực đơn được chuẩn bị một cách riêng biệt gồm “món ăn cho chàng”: Sườn cừu nướng kiểu Pháp và “món ăn cho nàng”: bò cuộn Wellington làm tăng thêm phần cuối hút của bữa tiệc. Nước Pháp lãng mạn chưa bao giờ khiến con người ta phải thất vọng bởi bản thân nó đã như một tác phẩm nghệ thuật của tạo hóa. Và cùng với sự tài hoa của những người đầu bếp người Pháp, sườn cừu nướng đã trở thành thứ khiến du khách say mê và lưu luyến. Và khi nhắc đến món Sườn cừu nướng thơm ngon ai cũng sẽ nghĩ đến ngay nước Pháp xinh đẹp, mà không phải một nơi nào khác. Vì sẽ không ở đâu hội tụ được đầy đủ sự tinh hoa vượt bậc, sự giá lạnh của thời tiết hay sự ngọt ngào của rượu vang đã tạo nên một món ăn mà không phải ở đâu cũng có hương vị như vậy. Cùng với khoai tây, sốt cherry anh đào và một ít rượu Porto, món sường cừu nướng kiểu Pháp luôn khiến cho thực khách khó quên bởi hương vị độc đáo mà nó đem lại. Sườn cừu nướng kiểu Pháp mang đến hai hương vị lạ lùng của thịt cừu và ẩm thực tinh tế của ẩm thực Pháp, một món ăn ngon tuyệt vời. Điểm đặc biệt và quyến rũ nhất trong món “Sườn cừu nướng” là sự kết hợp hài hòa đến tuyệt hảo của nước sốt và rượu Porto. 
        <img src="<?php echo public_url()?>/site/image/monan/beef_wellingtons.jpg" align="right" class="imgbst" style="width: 350px;margin-left: 10px;height: 250px;margin-top: 10px">
        Sự kết hợp ấy còn được ví như sự kết hợp của tình yêu trong vũ điệu Tango cổ điển, sự quyến luyến không thể tách rời tạo nên một món ăn khiến thực khách kích thích vị giác đến tột cùng. Bò cuộn Wellington gồm 3 phần quan trọng như phần lõi thịt bò, lớp nấm, phần vỏ pastry. Mỗi phần đều phải được trải qua công đoạn chế biến hết sức công phu, cầu kỳ để món ăn ngon đúng chuẩn vị từ trong ra ngoài. Có lẽ không cần biết qua các công đoạn chế biến cầu kỳ cũng như các nguyên liệu cao cấp mà chỉ cần nhìn các lát cắt của bò cuộn Wellington là bạn đủ cảm nhận đây là món ăn không phải "dạng tầm thường". Khi nếm thử món ăn, bạn sẽ cảm nhận ngay độ giòn hoàn hảo của vỏ bánh, độ thơm ngon và ngọt của lớp nấm cùng với thịt bò mềm như tan chảy trong miệng, chắc chắn nếu có cơ hội ăn thử một lần sẽ vô cùng thích thú. Thời xưa, món này chỉ xuất hiện trên các bàn tiệc của bậc vua chúa. Vậy nên, nếu muốn cùng người ấy thưởng thức một ngày Valentine sang chảnh, đây hẳn sẽ là lựa chọn bạn không nên bỏ qua. 
      </span><br>
      <span>
        <img src="<?php echo public_url()?>/site/image/monan/nicoise_salad.jpg" align="left" class="imgbst" style="width: 350px;margin-right: 10px;height: 250px;margin-top: 10px">
        
        Trong thực đơn 5 món dành cho ngày Lễ tình nhân French Foods chọn Nicoise salad là món salad phục vụ sau món chính. Ngon ngọt vì được làm từ nhiều loại rau quả tươi, Salad Nicoise sẽ mang đến cho bạn một hương vị vô cùng tuyệt vời. Salad Nicoise là món salad nổi tiếng đến từ nước Pháp và luôn xuất hiện trên thực đơn của các nhà hàng Pháp. Xa lát theo kiểu Nice là một món xà lát gồm cà chua, cá ngừ, trứng luộc già, ô liu vùng Nice và cá cơm biển, trộn với dầu giấm. Nó thường được bày vào đĩa, bát, có hoặc không có xà lách lót bên dưới. Cá ngừ có thể được nấu hoặc dùng loại đóng hộp. Món xa lát này có thể có thêm ớt chuông, hành khô và hoa atisô sống. Tuy nhiên món ăn không có một công thức chính thức, do vậy mỗi đầu bếp có thể quyết định công thức riêng của mình. Cá ngừ vị đậm đà kết hợp với sự mát lành từ rau trái, là sự thích thú khi cắn miếng rau giòn mát nhưng lại quyện vị bùi bùi, béo béo, dẻo dẻo của trứng và khoai tây, ăn kèm sốt chua nhẹ vị mặn tự nhiên thì đúng là chuẩn không cần chỉnh. Bạn sẽ ghi điểm tuyệt đối trong mắt nàng nhờ món sald tuyệt vời này.
      </span> <br>
      <span>
        <img src="<?php echo public_url()?>/site/image/monan/creme_brulee.jpg" align="right" class="imgbst1" style="width: 350px;margin-left: 10px;height: 250px;margin-top: 10px">
        
        Kết thúc một bữa tối kiểu Pháp cho ngày Lễ tình nhân thì không thể thiếu món tráng miệng. French Foods chuẩn bị cho các cặp tình nhân một món tráng miệng vô cùng ngọt ngào, hấp dẫn và đốn gục trái tim nàng chỉ trong cái nhìn đầu tiên. Đó là món kem cháy thơm nức mũi, thanh mát lại béo ngậy ai cũng thích mê.  Creme Brulee, còn được biết đến là kem cháy, crema catalana, hoặc kem Trinity là một món tráng miệng bao gồm một lớp đế custard béo phủ với một lớp nước caramen cứng. Người ta thường dùng nó ở nhiệt độ phòng. Đế custard theo truyền thống có hương vị vani, nhưng cũng có thể có nhiều loại vị khác. Món tráng miệng này thường được phục vụ lạnh. Loại kem này thường được pha thêm hương vị vanilla, nhưng có rất nhiều biến thể khác nhau của các công thức, trong đó có thể bao gồm một số lá hương thảo, sô cô la, các loại hạt khác nhau hoặc các loại rượu mùi, cà phê, chanh hoặc cam.Thưởng thức món kem cháy thơm thơm, beo béo lại có chút mát lạnh trong không gian lãng mạn tại nhà hàng French Foods thế này thật thích.

      </span>
    </p>
  </div>

   <div class="clear"></div>
   </div>
    <?php $this->load->view('site/footer');?>
    </body>
    <script type="text/javascript"></script>
</body>
</html>