</div>
        <script src="<?php echo public_url()?>/admin/css/js/jquery.min.js"></script>

        <script src="<?php echo public_url()?>/admin/css/js/bootstrap.min.js"></script>
        
        <script src="<?php echo public_url()?>/admin/css/js/metisMenu.min.js"></script>
        
        <script src="<?php echo public_url()?>/admin/css/js/dataTables/jquery.dataTables.min.js"></script>
        
        <script src="<?php echo public_url()?>/admin/css/js/dataTables/dataTables.bootstrap.min.js"></script>
        
        <script src="<?php echo public_url()?>/admin/css/js/script-app.js"></script>
        
        <script>
            $(document).ready(function() {
                $('#dataTables-example').DataTable({
                        responsive: true
                });
            });
        </script>

    </body>
</html>