<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Bst extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
	}

	public function bst4mua()
	{
		$data['user'] = $this->session->userdata('login');
		$this->load->view('site/bst/bst4mua',$data);
	}

	public function bstngayle()
	{
		$data['user'] = $this->session->userdata('login');
		$this->load->view('site/bst/bstngayle',$data);
	}
	
}