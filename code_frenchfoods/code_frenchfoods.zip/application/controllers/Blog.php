<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Blog extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper('date');
	}

	public function index()
	{
		$data['user'] = $this->session->userdata('login');
		$this->load->Model("Mblog");
		$data['nhanxet']=$this->Mblog->listall();
		$this->load->view('site/blog/index',$data);
	}

	public function nhanxet()
	{
		$hoten=$this->input->post('hoten');
		$email=$this->input->post('email');
		$sdt=$this->input->post('sdt');
		$ndnhanxet=$this->input->post('ndnhanxet');
		$dates = "%Y/%m/%d";
		$time1 = time();
		$time=mdate($dates, $time1);
		$trangthai=1;
		$data = array(
            'ngnhanxet' => $hoten,
            'email' => $email,
            'sdtnhanxet' => $sdt,
            'ndnhanxet' => $ndnhanxet,
            'thoigian' => $time,
            'trangthai' => $trangthai,
        );
		$this->load->model('Mblog');
		$this->Mblog->insert($data);
		// header("location:../thucdon/monan");
		?>
		<script type="text/javascript">
            alert('Nhận xét thành công!');
            window.location="../blog";
        </script>
        <?php
	}
}

/* End of file Blog.php */
/* Location: ./application/controllers/Blog.php */