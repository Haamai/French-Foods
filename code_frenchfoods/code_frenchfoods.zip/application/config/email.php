<?php 
 
$config['protocol'] = 'smtp';
$config['smtp_host'] = 'ssl://smtp.googlemail.com';
$config['smtp_user'] = 'hoangvu3600@gmail.com';
$config['smtp_pass'] = 'vult0718a';
$config['smtp_port'] = 465;
 
$config['charset'] = 'utf-8';
$config['mailtype'] = 'html';
$config['newline'] = "\r\n"; 